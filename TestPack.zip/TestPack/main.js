
// Theme switcher
var icon = document.getElementById("icon");
    icon.onclick = function(){
        document.body.classList.toggle("dark-theme");
        if(document.body.classList.contains("dark-theme")){
            icon.src = "images/sun.png";
        }
        else{
            icon.src = "images/moon.png";
        }
    }
// Search Filter

$('#myInput').keyup(function () { 
    $( ".card" ).each(function( index ) {
        var nameTag = $( this ).find('.countryName').text().toLowerCase();
        var searchStr = $('#myInput').val().toLowerCase();

        if (nameTag.indexOf(searchStr) == -1) {
            $(this).hide();
        } else {
            $(this).show();
        }
    });
});

// Dropdown Filter
$('#filterByCurrency').change(function () {    
    $( ".card" ).each(function( index ) {
        var nameTag = $( this ).find('.currency').text().toLowerCase();
        var searchStr = $('#filterByCurrency').val().toLowerCase();

        if (nameTag.indexOf(searchStr) == -1) {
            $(this).hide();
        } else {
            $(this).show();
        }
    });
});